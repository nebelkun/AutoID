﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
	public static class MachineWorker
	{
		public static bool RegisterMachine()
		{
			return false;
		}

		public static bool RemoveMachine()
		{
			return false;
		}

		public static bool UpdateMachine()
		{
			return false;
		}
	}
}