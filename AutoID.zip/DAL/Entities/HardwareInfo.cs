﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoID.Models
{
	public class HardwareInfo
	{
		public Guid ID { get; set; }
		public string CPUID { get; set; }
		public string Ram { get; set; }
		public string HardDriveId { get; set; }
		public string OS { get; set; }
	}
}