﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoID.Models
{
	public class Task
	{
		public Guid Id { get; set; }
		public int IssueType { get; set; }
		public int Priority { get; set; }
		public string Comment { get; set; }
		public DateTime OpenDate { get; set; }
		public DateTime ClosedDate { get; set; }
		public string AssigneeName { get; set; }
		public string ReporterName { get; set; }
	}
}
