﻿using System.Collections.Generic;
using System.Management;
using System.Windows;


namespace AutoIDClient
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
