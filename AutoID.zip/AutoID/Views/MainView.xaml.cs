﻿using System.Windows;

namespace AutoID.Views
{
	public partial class MainView : Window
	{
		public MainView()
		{
			InitializeComponent();
		}
	}
}