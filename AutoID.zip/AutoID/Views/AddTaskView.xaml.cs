﻿using System.Windows;

namespace AutoID.Views
{
	public partial class AddTaskView : Window
	{
		public AddTaskView()
		{
			InitializeComponent();
		}
	}
}
