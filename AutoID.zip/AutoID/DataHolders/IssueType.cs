﻿namespace AutoID.DataHolders
{
	public enum IssueType
	{
		Поломка = 1,
		Настройка = 2,
		Консультация = 3,
	}
}