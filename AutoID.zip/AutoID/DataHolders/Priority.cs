﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoID.DataHolders
{
	public enum Priority
	{
		Высокий = 1,
		Средний = 2,
		Низкий = 3,
	}
}
