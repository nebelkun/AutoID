﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoID.DataHolders
{
	public enum IssueStatus
	{
		Простой = 1,
		Работа = 2,
		Завершен = 3,
	}
}