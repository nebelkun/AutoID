﻿using System;
using Common.Helpers.WPF;
using AutoID.Views;

namespace AutoID.ViewModels
{
	public class MainViewModel : BaseViewModel
	{
		public MainViewModel()
		{
		}
	}
}